import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * ============================================================
 * JAVA FIRST - Student Management System
 * Class: FileHandler
 * ============================================================
 * This utility class handles all file operations for reading from
 * and saving to local persistent storage (data/students.txt).
 * 
 * Demonstrates:
 *  - Java File I/O (File, FileReader, FileWriter, BufferedReader, BufferedWriter)
 *  - Exception Handling (try-catch-finally, try-with-resources)
 *  - Directory & File verification/creation
 *  - Safe parsing and writing of collections
 */

public class FileHandler {

    /**
     * Ensures that the parent data directory and file exist.
     * If they do not exist, they are created automatically.
     *
     * @param filePath Relative or absolute path to the data file
     */
    public static void ensureFileExists(String filePath) {
        try {
            File file = new File(filePath);
            File parentDir = file.getParentFile();

            if (parentDir != null && !parentDir.exists()) {
                boolean dirCreated = parentDir.mkdirs();
                if (dirCreated) {
                    System.out.println("[INFO] Created data storage directory: " + parentDir.getPath());
                }
            }

            if (!file.exists()) {
                boolean fileCreated = file.createNewFile();
                if (fileCreated) {
                    System.out.println("[INFO] Created data file: " + file.getPath());
                }
            }
        } catch (IOException e) {
            System.err.println("[ERROR] Unable to create data file: " + e.getMessage());
        }
    }

    /**
     * Loads all students from the specified file into an ArrayList.
     *
     * @param filePath Path to the storage file (e.g., "data/students.txt")
     * @return List of Student objects loaded from the file
     */
    public static List<Student> loadStudents(String filePath) {
        List<Student> students = new ArrayList<>();
        ensureFileExists(filePath);

        File file = new File(filePath);
        if (!file.exists() || file.length() == 0) {
            return students; // Empty list if file is newly created or empty
        }

        // Try-with-resources automatically closes BufferedReader and FileReader
        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            int lineNumber = 0;

            while ((line = reader.readLine()) != null) {
                lineNumber++;
                line = line.trim();

                // Skip blank lines or comment lines starting with #
                if (line.isEmpty() || line.startsWith("#")) {
                    continue;
                }

                Student student = Student.fromCsvLine(line);
                if (student != null) {
                    students.add(student);
                } else {
                    System.err.println("[WARNING] Skipping corrupt record at line " + lineNumber + ": " + line);
                }
            }
        } catch (IOException e) {
            System.err.println("[ERROR] Failed to read student data from file: " + e.getMessage());
        }

        return students;
    }

    /**
     * Saves the entire list of students into the storage file.
     * Overwrites previous content with updated records.
     *
     * @param filePath Path to the storage file (e.g., "data/students.txt")
     * @param students List of Student objects to persist
     * @return true if save was successful, false otherwise
     */
    public static boolean saveStudents(String filePath, List<Student> students) {
        ensureFileExists(filePath);

        File file = new File(filePath);

        // Try-with-resources ensures BufferedWriter is flushed and closed cleanly
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(file, false))) {
            // Write informative header comment
            writer.write("# Java First - Student Management System Data Storage");
            writer.newLine();
            writer.write("# Format: StudentID,Name,Age,Course,Semester,Marks,Grade");
            writer.newLine();

            for (Student student : students) {
                writer.write(student.toCsvLine());
                writer.newLine();
            }
            return true;
        } catch (IOException e) {
            System.err.println("[ERROR] Failed to save student records to file: " + e.getMessage());
            return false;
        }
    }
}
