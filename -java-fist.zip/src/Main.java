import java.util.List;
import java.util.Scanner;

/**
 * ============================================================
 * JAVA FIRST - Student Management System
 * Class: Main (Console User Interface Entry Point)
 * ============================================================
 * This class serves as the presentation layer and program driver.
 * It provides an interactive command-line interface with robust
 * input validation, error handling, and clean formatting.
 * 
 * Features:
 *  1. Add Student (with duplicate ID check & auto-grade calculation)
 *  2. View All Students (tabular layout with summary metrics)
 *  3. Search Student (by Student ID or Name keyword)
 *  4. Update Student (with option to update specific fields)
 *  5. Delete Student (with confirmation prompt)
 *  6. Calculate Grade (grade system breakdown & interactive calculator)
 *  7. Exit (clean shutdown with data sync confirmation)
 */

public class Main {

    private static final Scanner scanner = new Scanner(System.in);
    private static final StudentManager manager = new StudentManager("data/students.txt");

    public static void main(String[] args) {
        printWelcomeBanner();

        boolean running = true;
        while (running) {
            displayMenu();
            int choice = readIntChoice("Enter your choice (1-7): ", 1, 7);

            System.out.println();
            switch (choice) {
                case 1:
                    handleAddStudent();
                    break;
                case 2:
                    handleViewAllStudents();
                    break;
                case 3:
                    handleSearchStudent();
                    break;
                case 4:
                    handleUpdateStudent();
                    break;
                case 5:
                    handleDeleteStudent();
                    break;
                case 6:
                    handleCalculateGrade();
                    break;
                case 7:
                    handleExit();
                    running = false;
                    break;
                default:
                    System.out.println("[!] Invalid choice. Please select an option between 1 and 7.");
            }

            if (running) {
                pressEnterToContinue();
            }
        }

        scanner.close();
    }

    // ------------------------------------------------------------
    // UI Displays & Menus
    // ------------------------------------------------------------

    private static void printWelcomeBanner() {
        System.out.println("=================================================");
        System.out.println("            JAVA FIRST: STUDENT MANAGEMENT       ");
        System.out.println("=================================================");
        System.out.println(" Welcome to the BCA Core Java Management System! ");
        System.out.println(" Persistent Data File: data/students.txt         ");
        System.out.println(" Total Records Loaded: " + manager.getTotalCount());
        System.out.println("=================================================\n");
    }

    private static void displayMenu() {
        System.out.println("=================================");
        System.out.println("           JAVA FIRST            ");
        System.out.println("    Student Management System    ");
        System.out.println("=================================");
        System.out.println("1. Add Student");
        System.out.println("2. View All Students");
        System.out.println("3. Search Student");
        System.out.println("4. Update Student");
        System.out.println("5. Delete Student");
        System.out.println("6. Calculate Grade");
        System.out.println("7. Exit");
        System.out.println("=================================");
    }

    // ------------------------------------------------------------
    // Option 1: Add Student
    // ------------------------------------------------------------

    private static void handleAddStudent() {
        System.out.println("---------------------------------");
        System.out.println("       ADD NEW STUDENT           ");
        System.out.println("---------------------------------");

        String studentId;
        while (true) {
            studentId = readNonEmptyString("Enter Student ID (e.g., S101): ").toUpperCase();
            if (manager.isIdDuplicate(studentId)) {
                System.out.println("[!] Error: Student ID '" + studentId + "' already exists! Please use a unique ID.");
            } else {
                break;
            }
        }

        String name = readNonEmptyString("Enter Student Name: ");
        int age = readIntChoice("Enter Age (15 - 100): ", 15, 100);
        String course = readNonEmptyString("Enter Course (e.g., BCA, B.Tech, MCA): ").toUpperCase();
        int semester = readIntChoice("Enter Semester (1 - 8): ", 1, 8);
        double marks = readDoubleChoice("Enter Marks (0.0 - 100.0): ", 0.0, 100.0);

        // Create student instance (Grade is computed automatically in constructor)
        Student newStudent = new Student(studentId, name, age, course, semester, marks);

        boolean added = manager.addStudent(newStudent);
        if (added) {
            System.out.println("\n[SUCCESS] Student registered successfully!");
            displayStudentCard(newStudent);
        } else {
            System.out.println("\n[ERROR] Failed to add student. Please try again.");
        }
    }

    // ------------------------------------------------------------
    // Option 2: View All Students
    // ------------------------------------------------------------

    private static void handleViewAllStudents() {
        System.out.println("-----------------------------------------------------------------------------------------");
        System.out.println("                                   ALL REGISTERED STUDENTS                               ");
        System.out.println("-----------------------------------------------------------------------------------------");

        List<Student> list = manager.getAllStudents();
        if (list.isEmpty()) {
            System.out.println("[INFO] No student records found. Choose Option 1 to add students.");
            return;
        }

        // Print Formatted Table Header
        System.out.printf("| %-8s | %-20s | %-4s | %-10s | %-4s | %-7s | %-6s |%n",
                "ID", "Name", "Age", "Course", "Sem", "Marks", "Grade");
        System.out.println("|----------|----------------------|------|------------|------|---------|--------|");

        // Print Each Student Row
        for (Student s : list) {
            System.out.printf("| %-8s | %-20s | %-4d | %-10s | %-4d | %-7.2f | %-6s |%n",
                    s.getStudentId(),
                    truncate(s.getName(), 20),
                    s.getAge(),
                    truncate(s.getCourse(), 10),
                    s.getSemester(),
                    s.getMarks(),
                    s.getGrade());
        }
        System.out.println("-----------------------------------------------------------------------------------------");
        System.out.printf(" Total Students: %d   |   Class Average Marks: %.2f%%%n",
                manager.getTotalCount(), manager.calculateClassAverageMarks());
    }

    // ------------------------------------------------------------
    // Option 3: Search Student
    // ------------------------------------------------------------

    private static void handleSearchStudent() {
        System.out.println("---------------------------------");
        System.out.println("         SEARCH STUDENT          ");
        System.out.println("---------------------------------");
        System.out.println("1. Search by Student ID");
        System.out.println("2. Search by Student Name (Keyword)");
        System.out.println("---------------------------------");

        int subChoice = readIntChoice("Enter search criteria (1-2): ", 1, 2);

        if (subChoice == 1) {
            String searchId = readNonEmptyString("Enter Student ID to find: ");
            Student student = manager.findStudentById(searchId);

            if (student != null) {
                System.out.println("\n[MATCH FOUND]");
                displayStudentCard(student);
            } else {
                System.out.println("\n[!] No student found with ID: " + searchId);
            }
        } else {
            String keyword = readNonEmptyString("Enter Name keyword to search: ");
            List<Student> results = manager.searchStudentsByName(keyword);

            if (results.isEmpty()) {
                System.out.println("\n[!] No students found matching name: '" + keyword + "'");
            } else {
                System.out.println("\nFound " + results.size() + " matching student(s):");
                for (Student s : results) {
                    displayStudentCard(s);
                }
            }
        }
    }

    // ------------------------------------------------------------
    // Option 4: Update Student
    // ------------------------------------------------------------

    private static void handleUpdateStudent() {
        System.out.println("---------------------------------");
        System.out.println("         UPDATE STUDENT          ");
        System.out.println("---------------------------------");

        String studentId = readNonEmptyString("Enter Student ID to update: ");
        Student student = manager.findStudentById(studentId);

        if (student == null) {
            System.out.println("[!] No student found with ID: " + studentId);
            return;
        }

        System.out.println("\n--- Current Details ---");
        displayStudentCard(student);

        System.out.println("\n--- Enter New Details (or re-enter current values) ---");
        String newName = readNonEmptyString("Enter New Name [" + student.getName() + "]: ");
        int newAge = readIntChoice("Enter New Age [" + student.getAge() + "] (15 - 100): ", 15, 100);
        String newCourse = readNonEmptyString("Enter New Course [" + student.getCourse() + "]: ").toUpperCase();
        int newSemester = readIntChoice("Enter New Semester [" + student.getSemester() + "] (1 - 8): ", 1, 8);
        double newMarks = readDoubleChoice("Enter New Marks [" + student.getMarks() + "] (0.0 - 100.0): ", 0.0, 100.0);

        boolean updated = manager.updateStudent(student.getStudentId(), newName, newAge, newCourse, newSemester, newMarks);
        if (updated) {
            System.out.println("\n[SUCCESS] Student updated successfully!");
            displayStudentCard(manager.findStudentById(studentId));
        } else {
            System.out.println("\n[ERROR] Failed to update student record.");
        }
    }

    // ------------------------------------------------------------
    // Option 5: Delete Student
    // ------------------------------------------------------------

    private static void handleDeleteStudent() {
        System.out.println("---------------------------------");
        System.out.println("         DELETE STUDENT          ");
        System.out.println("---------------------------------");

        String studentId = readNonEmptyString("Enter Student ID to delete: ");
        Student student = manager.findStudentById(studentId);

        if (student == null) {
            System.out.println("[!] No student found with ID: " + studentId);
            return;
        }

        System.out.println("\nTarget Record:");
        displayStudentCard(student);

        String confirm = readNonEmptyString("Are you sure you want to permanently delete this student? (Y/N): ");
        if (confirm.equalsIgnoreCase("Y") || confirm.equalsIgnoreCase("YES")) {
            boolean deleted = manager.deleteStudent(studentId);
            if (deleted) {
                System.out.println("\n[SUCCESS] Student record '" + studentId + "' deleted successfully!");
            } else {
                System.out.println("\n[ERROR] Could not delete student.");
            }
        } else {
            System.out.println("\n[CANCELLED] Deletion cancelled by user.");
        }
    }

    // ------------------------------------------------------------
    // Option 6: Calculate Grade
    // ------------------------------------------------------------

    private static void handleCalculateGrade() {
        System.out.println("-------------------------------------------------");
        System.out.println("             GRADE EVALUATION CENTER             ");
        System.out.println("-------------------------------------------------");
        System.out.println("Official Grading Scale:");
        System.out.println("  * 90.0 - 100.0 -> Grade A+  (Outstanding)");
        System.out.println("  * 80.0 - 89.9  -> Grade A   (Excellent)");
        System.out.println("  * 70.0 - 79.9  -> Grade B   (Very Good)");
        System.out.println("  * 60.0 - 69.9  -> Grade C   (Good)");
        System.out.println("  * 50.0 - 59.9  -> Grade D   (Pass)");
        System.out.println("  * Below 50.0   -> Grade F   (Fail)");
        System.out.println("-------------------------------------------------");
        System.out.println("1. Calculate Grade for a Custom Marks Input");
        System.out.println("2. Check/Verify Grade of an Enrolled Student");
        System.out.println("-------------------------------------------------");

        int mode = readIntChoice("Choose calculation mode (1-2): ", 1, 2);

        if (mode == 1) {
            double testMarks = readDoubleChoice("Enter Marks to evaluate (0.0 - 100.0): ", 0.0, 100.0);
            String grade = Student.calculateGrade(testMarks);
            String remark = Student.getGradeRemark(grade);

            System.out.println("\n=================================");
            System.out.printf(" Scored Marks : %.2f / 100.00%n", testMarks);
            System.out.printf(" Grade Awarded: %s%n", grade);
            System.out.printf(" Performance  : %s%n", remark);
            System.out.println("=================================");
        } else {
            String studentId = readNonEmptyString("Enter Enrolled Student ID: ");
            Student student = manager.findStudentById(studentId);

            if (student != null) {
                String grade = student.getGrade();
                String remark = Student.getGradeRemark(grade);

                System.out.println("\n=================================");
                System.out.printf(" Student Name : %s (%s)%n", student.getName(), student.getStudentId());
                System.out.printf(" Course / Sem : %s / Sem %d%n", student.getCourse(), student.getSemester());
                System.out.printf(" Scored Marks : %.2f / 100.00%n", student.getMarks());
                System.out.printf(" Grade Awarded: %s%n", grade);
                System.out.printf(" Performance  : %s%n", remark);
                System.out.println("=================================");
            } else {
                System.out.println("\n[!] No student found with ID: " + studentId);
            }
        }
    }

    // ------------------------------------------------------------
    // Option 7: Exit
    // ------------------------------------------------------------

    private static void handleExit() {
        System.out.println("Saving all data to data/students.txt...");
        manager.persistData();
        System.out.println("=================================================");
        System.out.println(" Thank you for using Java First - SMS!");
        System.out.println(" All student data is safely saved.");
        System.out.println(" Have a great day!");
        System.out.println("=================================================");
    }

    // ------------------------------------------------------------
    // Helper & Validation Methods (Input Safeguards)
    // ------------------------------------------------------------

    /**
     * Reads a non-empty, trimmed string from the console.
     */
    private static String readNonEmptyString(String prompt) {
        while (true) {
            System.out.print(prompt);
            String input = scanner.nextLine();
            if (input != null && !input.trim().isEmpty()) {
                return input.trim();
            }
            System.out.println("[!] Input cannot be empty. Please enter a valid value.");
        }
    }

    /**
     * Reads an integer within [min, max] range safely without scanner crashes.
     */
    private static int readIntChoice(String prompt, int min, int max) {
        while (true) {
            System.out.print(prompt);
            String line = scanner.nextLine();
            try {
                int value = Integer.parseInt(line.trim());
                if (value >= min && value <= max) {
                    return value;
                }
                System.out.printf("[!] Please enter a number between %d and %d.%n", min, max);
            } catch (NumberFormatException e) {
                System.out.println("[!] Invalid number format. Please enter an integer value.");
            }
        }
    }

    /**
     * Reads a double value within [min, max] range safely.
     */
    private static double readDoubleChoice(String prompt, double min, double max) {
        while (true) {
            System.out.print(prompt);
            String line = scanner.nextLine();
            try {
                double value = Double.parseDouble(line.trim());
                if (value >= min && value <= max) {
                    return value;
                }
                System.out.printf("[!] Please enter a value between %.2f and %.2f.%n", min, max);
            } catch (NumberFormatException e) {
                System.out.println("[!] Invalid decimal number. Please enter a numeric value.");
            }
        }
    }

    /**
     * Displays a clean formatted card for a single Student.
     */
    private static void displayStudentCard(Student s) {
        System.out.println("+----------------------------------------+");
        System.out.printf("| Student ID : %-25s |%n", s.getStudentId());
        System.out.printf("| Name       : %-25s |%n", truncate(s.getName(), 25));
        System.out.printf("| Age        : %-25d |%n", s.getAge());
        System.out.printf("| Course     : %-25s |%n", truncate(s.getCourse(), 25));
        System.out.printf("| Semester   : %-25d |%n", s.getSemester());
        System.out.printf("| Marks      : %-25.2f |%n", s.getMarks());
        System.out.printf("| Grade      : %-25s |%n", s.getGrade() + " (" + Student.getGradeRemark(s.getGrade()) + ")");
        System.out.println("+----------------------------------------+");
    }

    /**
     * Truncates long strings to prevent table distortion.
     */
    private static String truncate(String str, int maxLen) {
        if (str == null) return "";
        if (str.length() <= maxLen) return str;
        return str.substring(0, maxLen - 3) + "...";
    }

    /**
     * Pauses console flow until user presses Enter key.
     */
    private static void pressEnterToContinue() {
        System.out.println("\nPress [Enter] to return to the Main Menu...");
        scanner.nextLine();
    }
}
