/**
 * ============================================================
 * JAVA FIRST - Student Management System
 * Class: Student
 * ============================================================
 * This class represents an individual Student entity in the system.
 * It demonstrates Core Java OOP concepts:
 *  - Encapsulation (private fields, public getters and setters)
 *  - Constructors (Default and Parameterized)
 *  - Methods (Custom helper methods for grade calculation and data formatting)
 *  - Data Parsing & Serialization (CSV to/from Object mapping)
 */

public class Student {
    // ------------------------------------------------------------
    // Private attributes (Encapsulation)
    // ------------------------------------------------------------
    private String studentId;
    private String name;
    private int age;
    private String course;
    private int semester;
    private double marks;
    private String grade;

    // ------------------------------------------------------------
    // Constructors
    // ------------------------------------------------------------

    /**
     * Default no-argument constructor.
     */
    public Student() {
        this.studentId = "";
        this.name = "";
        this.age = 0;
        this.course = "";
        this.semester = 1;
        this.marks = 0.0;
        this.grade = "F";
    }

    /**
     * Parameterized constructor without explicit grade.
     * Automatically calculates the grade based on marks.
     *
     * @param studentId Unique identifier for the student (e.g., "S101")
     * @param name      Full name of the student
     * @param age       Age in years
     * @param course    Enrolled course (e.g., "BCA", "B.Tech", "MCA")
     * @param semester  Current semester (1 to 8)
     * @param marks     Academic marks scored (0.0 to 100.0)
     */
    public Student(String studentId, String name, int age, String course, int semester, double marks) {
        this.studentId = studentId.trim();
        this.name = name.trim();
        this.age = age;
        this.course = course.trim();
        this.semester = semester;
        this.marks = marks;
        this.grade = calculateGrade(marks);
    }

    /**
     * Parameterized constructor with explicit grade.
     *
     * @param studentId Unique identifier
     * @param name      Full name
     * @param age       Age in years
     * @param course    Course name
     * @param semester  Semester number
     * @param marks     Marks scored
     * @param grade     Letter grade
     */
    public Student(String studentId, String name, int age, String course, int semester, double marks, String grade) {
        this.studentId = studentId.trim();
        this.name = name.trim();
        this.age = age;
        this.course = course.trim();
        this.semester = semester;
        this.marks = marks;
        this.grade = (grade == null || grade.trim().isEmpty()) ? calculateGrade(marks) : grade.trim();
    }

    // ------------------------------------------------------------
    // Business Logic / Static Helper Methods
    // ------------------------------------------------------------

    /**
     * Calculates the letter grade according to academic standards:
     *  90.0 - 100.0 -> A+ (Outstanding)
     *  80.0 - 89.9  -> A  (Excellent)
     *  70.0 - 79.9  -> B  (Very Good)
     *  60.0 - 69.9  -> C  (Good)
     *  50.0 - 59.9  -> D  (Pass)
     *  Below 50.0   -> F  (Fail)
     *
     * @param marks Percentage or total marks out of 100
     * @return Letter grade as String
     */
    public static String calculateGrade(double marks) {
        if (marks >= 90.0) {
            return "A+";
        } else if (marks >= 80.0) {
            return "A";
        } else if (marks >= 70.0) {
            return "B";
        } else if (marks >= 60.0) {
            return "C";
        } else if (marks >= 50.0) {
            return "D";
        } else {
            return "F";
        }
    }

    /**
     * Returns a descriptive remark for a given letter grade.
     *
     * @param grade The letter grade
     * @return Remark string
     */
    public static String getGradeRemark(String grade) {
        if (grade == null) return "Unknown";
        switch (grade.toUpperCase()) {
            case "A+": return "Outstanding Performance";
            case "A":  return "Excellent Performance";
            case "B":  return "Very Good Performance";
            case "C":  return "Good Performance";
            case "D":  return "Pass / Satisfactory";
            case "F":  return "Fail (Needs Improvement)";
            default:   return "N/A";
        }
    }

    // ------------------------------------------------------------
    // Getters and Setters (Encapsulation)
    // ------------------------------------------------------------

    public String getStudentId() {
        return studentId;
    }

    public void setStudentId(String studentId) {
        this.studentId = studentId.trim();
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name.trim();
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        if (age > 0) {
            this.age = age;
        }
    }

    public String getCourse() {
        return course;
    }

    public void setCourse(String course) {
        this.course = course.trim();
    }

    public int getSemester() {
        return semester;
    }

    public void setSemester(int semester) {
        if (semester >= 1 && semester <= 8) {
            this.semester = semester;
        }
    }

    public double getMarks() {
        return marks;
    }

    /**
     * Updates marks and automatically recalculates the grade.
     *
     * @param marks New marks value (0.0 to 100.0)
     */
    public void setMarks(double marks) {
        this.marks = marks;
        this.grade = calculateGrade(marks);
    }

    public String getGrade() {
        return grade;
    }

    public void setGrade(String grade) {
        this.grade = grade;
    }

    // ------------------------------------------------------------
    // File Serialization Helpers (CSV format)
    // ------------------------------------------------------------

    /**
     * Converts student object data into a comma-separated format for file persistence.
     * Format: studentId,name,age,course,semester,marks,grade
     *
     * @return CSV formatted string
     */
    public String toCsvLine() {
        // Replace commas in strings to avoid corrupting CSV columns
        String safeName = name.replace(",", " ");
        String safeCourse = course.replace(",", " ");
        return String.format(java.util.Locale.US, "%s,%s,%d,%s,%d,%.2f,%s",
                studentId, safeName, age, safeCourse, semester, marks, grade);
    }

    /**
     * Parses a CSV formatted line from file into a Student object.
     *
     * @param line Comma-separated string from file
     * @return Student instance or null if line format is invalid
     */
    public static Student fromCsvLine(String line) {
        if (line == null || line.trim().isEmpty()) {
            return null;
        }

        // Split by comma
        String[] parts = line.split(",");
        if (parts.length < 6) {
            return null; // Insufficient columns
        }

        try {
            String studentId = parts[0].trim();
            String name = parts[1].trim();
            int age = Integer.parseInt(parts[2].trim());
            String course = parts[3].trim();
            int semester = Integer.parseInt(parts[4].trim());
            double marks = Double.parseDouble(parts[5].trim());
            String grade = (parts.length >= 7) ? parts[6].trim() : calculateGrade(marks);

            return new Student(studentId, name, age, course, semester, marks, grade);
        } catch (NumberFormatException | ArrayIndexOutOfBoundsException e) {
            // Return null to signify corrupted line
            return null;
        }
    }

    // ------------------------------------------------------------
    // Display Helper Methods
    // ------------------------------------------------------------

    @Override
    public String toString() {
        return String.format("Student [ID=%s, Name=%s, Age=%d, Course=%s, Sem=%d, Marks=%.2f, Grade=%s]",
                studentId, name, age, course, semester, marks, grade);
    }
}
