import java.util.ArrayList;
import java.util.List;

/**
 * ============================================================
 * JAVA FIRST - Student Management System
 * Class: StudentManager
 * ============================================================
 * This class serves as the core Business Logic and Service layer.
 * It manages an in-memory ArrayList of Student objects and synchronizes
 * changes with the local persistent file storage via FileHandler.
 * 
 * Demonstrates:
 *  - Collections Framework (ArrayList, List operations)
 *  - Searching, Sorting, Filtering algorithms
 *  - CRUD Operations (Create, Read, Update, Delete)
 *  - Modular Method Design
 */

public class StudentManager {
    // In-memory list to hold students dynamically
    private List<Student> students;
    
    // File path for persistence
    private final String dataFilePath;

    /**
     * Default constructor initializing with default storage path: data/students.txt
     */
    public StudentManager() {
        this("data/students.txt");
    }

    /**
     * Parameterized constructor allowing custom file path (useful for testing).
     *
     * @param dataFilePath Relative path to storage file
     */
    public StudentManager(String dataFilePath) {
        this.dataFilePath = dataFilePath;
        this.students = new ArrayList<>();
        loadDataFromFile();
    }

    /**
     * Loads student data from file storage into memory.
     */
    public void loadDataFromFile() {
        this.students = FileHandler.loadStudents(dataFilePath);
    }

    /**
     * Saves the current in-memory student collection to file storage.
     *
     * @return true if save was successful
     */
    public boolean persistData() {
        return FileHandler.saveStudents(dataFilePath, students);
    }

    // ------------------------------------------------------------
    // 1. Add Student
    // ------------------------------------------------------------

    /**
     * Adds a new student if the student ID is not duplicate.
     *
     * @param student The Student object to add
     * @return true if student was added successfully, false if duplicate ID exists
     */
    public boolean addStudent(Student student) {
        if (student == null) {
            return false;
        }

        // Validate uniqueness of student ID
        if (isIdDuplicate(student.getStudentId())) {
            return false;
        }

        students.add(student);
        persistData(); // Automatically sync with file
        return true;
    }

    // ------------------------------------------------------------
    // 2. View All Students
    // ------------------------------------------------------------

    /**
     * Returns the full list of enrolled students.
     *
     * @return List of all Student objects
     */
    public List<Student> getAllStudents() {
        return new ArrayList<>(students); // Return copy to preserve internal state encapsulation
    }

    /**
     * Returns total count of students currently registered.
     *
     * @return count as integer
     */
    public int getTotalCount() {
        return students.size();
    }

    /**
     * Calculates the class average marks across all registered students.
     *
     * @return Average marks, or 0.0 if no students exist
     */
    public double calculateClassAverageMarks() {
        if (students.isEmpty()) {
            return 0.0;
        }
        double sum = 0;
        for (Student s : students) {
            sum += s.getMarks();
        }
        return sum / students.size();
    }

    // ------------------------------------------------------------
    // 3. Search Student
    // ------------------------------------------------------------

    /**
     * Searches for a student by their unique Student ID (case-insensitive).
     *
     * @param studentId ID to look up
     * @return Student object if found, or null if not found
     */
    public Student findStudentById(String studentId) {
        if (studentId == null || studentId.trim().isEmpty()) {
            return null;
        }

        String searchId = studentId.trim().toUpperCase();
        for (Student student : students) {
            if (student.getStudentId().equalsIgnoreCase(searchId)) {
                return student;
            }
        }
        return null;
    }

    /**
     * Searches for students matching a name keyword (case-insensitive substring match).
     *
     * @param nameQuery Keyword to search for in student names
     * @return List of matching Student objects
     */
    public List<Student> searchStudentsByName(String nameQuery) {
        List<Student> matches = new ArrayList<>();
        if (nameQuery == null || nameQuery.trim().isEmpty()) {
            return matches;
        }

        String query = nameQuery.trim().toLowerCase();
        for (Student student : students) {
            if (student.getName().toLowerCase().contains(query)) {
                matches.add(student);
            }
        }
        return matches;
    }

    // ------------------------------------------------------------
    // 4. Update Student
    // ------------------------------------------------------------

    /**
     * Updates details of an existing student and saves to file.
     *
     * @param studentId   Target student ID
     * @param newName     Updated name
     * @param newAge      Updated age
     * @param newCourse   Updated course
     * @param newSemester Updated semester
     * @param newMarks    Updated marks
     * @return true if student was found and updated, false otherwise
     */
    public boolean updateStudent(String studentId, String newName, int newAge, String newCourse, int newSemester, double newMarks) {
        Student target = findStudentById(studentId);
        if (target == null) {
            return false;
        }

        target.setName(newName);
        target.setAge(newAge);
        target.setCourse(newCourse);
        target.setSemester(newSemester);
        target.setMarks(newMarks); // Automatically recalculates grade

        persistData(); // Sync updated records to file
        return true;
    }

    // ------------------------------------------------------------
    // 5. Delete Student
    // ------------------------------------------------------------

    /**
     * Deletes a student from the system by their unique ID.
     *
     * @param studentId ID of student to remove
     * @return true if student was found and removed, false otherwise
     */
    public boolean deleteStudent(String studentId) {
        Student target = findStudentById(studentId);
        if (target == null) {
            return false;
        }

        boolean removed = students.remove(target);
        if (removed) {
            persistData(); // Sync updated list to file
        }
        return removed;
    }

    // ------------------------------------------------------------
    // 6. Utility & Validation Checks
    // ------------------------------------------------------------

    /**
     * Checks whether a given Student ID already exists in the system.
     *
     * @param studentId ID string to verify
     * @return true if ID is already in use, false otherwise
     */
    public boolean isIdDuplicate(String studentId) {
        return findStudentById(studentId) != null;
    }

    /**
     * Checks if the student collection is currently empty.
     *
     * @return true if no students exist
     */
    public boolean isEmpty() {
        return students.isEmpty();
    }
}
