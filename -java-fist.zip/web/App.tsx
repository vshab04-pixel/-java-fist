import React, { useState, useEffect, useRef } from 'react';
import { 
  Terminal, 
  Code2, 
  FileText, 
  FolderTree, 
  Play, 
  RotateCcw, 
  CheckCircle2, 
  Copy, 
  BookOpen, 
  GraduationCap, 
  Users, 
  HardDrive, 
  Award, 
  Search, 
  Plus, 
  Trash2, 
  Edit3, 
  Database,
  ExternalLink,
  ChevronRight
} from 'lucide-react';

interface StudentData {
  id: string;
  name: string;
  age: number;
  course: string;
  semester: number;
  marks: number;
  grade: string;
}

const INITIAL_STUDENTS: StudentData[] = [
  { id: 'S101', name: 'Aarav Sharma', age: 20, course: 'BCA', semester: 4, marks: 92.50, grade: 'A+' },
  { id: 'S102', name: 'Priya Patel', age: 19, course: 'BCA', semester: 2, marks: 84.00, grade: 'A' },
  { id: 'S103', name: 'Rohan Verma', age: 21, course: 'B.Tech', semester: 6, marks: 76.50, grade: 'B' },
  { id: 'S104', name: 'Sneha Gupta', age: 20, course: 'BSc CS', semester: 3, marks: 63.00, grade: 'C' },
  { id: 'S105', name: 'Vikram Singh', age: 22, course: 'MCA', semester: 2, marks: 48.00, grade: 'F' }
];

const JAVA_CODE_FILES: Record<string, { filename: string; path: string; language: string; description: string; code: string }> = {
  student: {
    filename: 'Student.java',
    path: 'src/Student.java',
    language: 'java',
    description: 'Encapsulated Entity Model containing private fields, constructors, getters/setters, auto-grade logic, and CSV converters.',
    code: `/**
 * JAVA FIRST - Student Management System
 * Class: Student
 */
public class Student {
    private String studentId;
    private String name;
    private int age;
    private String course;
    private int semester;
    private double marks;
    private String grade;

    // Constructors
    public Student() { ... }
    
    public Student(String studentId, String name, int age, String course, int semester, double marks) {
        this.studentId = studentId.trim();
        this.name = name.trim();
        this.age = age;
        this.course = course.trim();
        this.semester = semester;
        this.marks = marks;
        this.grade = calculateGrade(marks);
    }

    public static String calculateGrade(double marks) {
        if (marks >= 90.0) return "A+";
        else if (marks >= 80.0) return "A";
        else if (marks >= 70.0) return "B";
        else if (marks >= 60.0) return "C";
        else if (marks >= 50.0) return "D";
        else return "F";
    }

    // Getters & Setters ...
    public String toCsvLine() {
        return String.format("%s,%s,%d,%s,%d,%.2f,%s",
                studentId, name, age, course, semester, marks, grade);
    }
}`
  },
  studentManager: {
    filename: 'StudentManager.java',
    path: 'src/StudentManager.java',
    language: 'java',
    description: 'Business logic layer holding the in-memory ArrayList<Student> and executing CRUD queries synchronized with FileHandler.',
    code: `/**
 * JAVA FIRST - Student Management System
 * Class: StudentManager
 */
public class StudentManager {
    private List<Student> students;
    private final String dataFilePath;

    public StudentManager(String dataFilePath) {
        this.dataFilePath = dataFilePath;
        this.students = new ArrayList<>();
        loadDataFromFile();
    }

    public boolean addStudent(Student student) {
        if (isIdDuplicate(student.getStudentId())) return false;
        students.add(student);
        persistData();
        return true;
    }

    public Student findStudentById(String studentId) {
        for (Student s : students) {
            if (s.getStudentId().equalsIgnoreCase(studentId)) return s;
        }
        return null;
    }

    public boolean updateStudent(String studentId, String newName, int newAge, String newCourse, int newSemester, double newMarks) {
        Student target = findStudentById(studentId);
        if (target == null) return false;
        target.setName(newName);
        target.setAge(newAge);
        target.setCourse(newCourse);
        target.setSemester(newSemester);
        target.setMarks(newMarks);
        persistData();
        return true;
    }
}`
  },
  fileHandler: {
    filename: 'FileHandler.java',
    path: 'src/FileHandler.java',
    language: 'java',
    description: 'Persistent file handler utilizing BufferedReader and BufferedWriter to safely read and save data/students.txt records.',
    code: `/**
 * JAVA FIRST - Student Management System
 * Class: FileHandler
 */
public class FileHandler {
    public static List<Student> loadStudents(String filePath) {
        List<Student> students = new ArrayList<>();
        ensureFileExists(filePath);
        File file = new File(filePath);

        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.trim().isEmpty() || line.startsWith("#")) continue;
                Student student = Student.fromCsvLine(line);
                if (student != null) students.add(student);
            }
        } catch (IOException e) {
            System.err.println("[ERROR] Failed to read: " + e.getMessage());
        }
        return students;
    }

    public static boolean saveStudents(String filePath, List<Student> students) {
        ensureFileExists(filePath);
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filePath, false))) {
            writer.write("# Java First - Student Management System Data Storage\\n");
            for (Student student : students) {
                writer.write(student.toCsvLine());
                writer.newLine();
            }
            return true;
        } catch (IOException e) {
            return false;
        }
    }
}`
  },
  main: {
    filename: 'Main.java',
    path: 'src/Main.java',
    language: 'java',
    description: 'Console User Interface Driver featuring 7 interactive menu options, robust Scanner validation, and formatted tabular outputs.',
    code: `/**
 * JAVA FIRST - Student Management System
 * Class: Main
 */
public class Main {
    private static final Scanner scanner = new Scanner(System.in);
    private static final StudentManager manager = new StudentManager("data/students.txt");

    public static void main(String[] args) {
        printWelcomeBanner();
        boolean running = true;
        while (running) {
            displayMenu();
            int choice = readIntChoice("Enter your choice (1-7): ", 1, 7);
            switch (choice) {
                case 1: handleAddStudent(); break;
                case 2: handleViewAllStudents(); break;
                case 3: handleSearchStudent(); break;
                case 4: handleUpdateStudent(); break;
                case 5: handleDeleteStudent(); break;
                case 6: handleCalculateGrade(); break;
                case 7: handleExit(); running = false; break;
            }
        }
    }
}`
  },
  data: {
    filename: 'students.txt',
    path: 'data/students.txt',
    language: 'text',
    description: 'Local flat-file CSV database storing student records with automatic headers.',
    code: `# Java First - Student Management System Data Storage
# Format: StudentID,Name,Age,Course,Semester,Marks,Grade
S101,Aarav Sharma,20,BCA,4,92.50,A+
S102,Priya Patel,19,BCA,2,84.00,A
S103,Rohan Verma,21,B.Tech,6,76.50,B
S104,Sneha Gupta,20,BSc CS,3,63.00,C
S105,Vikram Singh,22,MCA,2,48.00,F`
  }
};

export default function App() {
  const [activeTab, setActiveTab] = useState<'console' | 'code' | 'students' | 'guide'>('console');
  const [selectedFile, setSelectedFile] = useState<string>('student');
  const [students, setStudents] = useState<StudentData[]>(INITIAL_STUDENTS);
  
  // Console state
  const [terminalLogs, setTerminalLogs] = useState<string[]>([
    "=================================================",
    "            JAVA FIRST: STUDENT MANAGEMENT       ",
    "=================================================",
    " Welcome to the BCA Core Java Management System! ",
    " Persistent Data File: data/students.txt         ",
    " Total Records Loaded: 5                         ",
    "=================================================\n",
    "=================================",
    "           JAVA FIRST            ",
    "    Student Management System    ",
    "=================================",
    "1. Add Student",
    "2. View All Students",
    "3. Search Student",
    "4. Update Student",
    "5. Delete Student",
    "6. Calculate Grade",
    "7. Exit",
    "================================="
  ]);
  const [inputVal, setInputVal] = useState<string>('');
  const [copiedCmd, setCopiedCmd] = useState<string | null>(null);
  const terminalEndRef = useRef<HTMLDivElement>(null);

  // Quick form state for Interactive Add/Grade
  const [testMarks, setTestMarks] = useState<number>(85.5);
  const [gradeResult, setGradeResult] = useState<{ grade: string; remark: string }>({ grade: 'A', remark: 'Excellent Performance' });

  // Filter & search state
  const [searchTerm, setSearchTerm] = useState('');

  useEffect(() => {
    terminalEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [terminalLogs]);

  const calculateGrade = (m: number) => {
    if (m >= 90.0) return { grade: 'A+', remark: 'Outstanding Performance' };
    if (m >= 80.0) return { grade: 'A', remark: 'Excellent Performance' };
    if (m >= 70.0) return { grade: 'B', remark: 'Very Good Performance' };
    if (m >= 60.0) return { grade: 'C', remark: 'Good Performance' };
    if (m >= 50.0) return { grade: 'D', remark: 'Pass / Satisfactory' };
    return { grade: 'F', remark: 'Fail (Needs Improvement)' };
  };

  const handleRunCommand = (choice: number) => {
    let output: string[] = [];
    output.push(`\n> User selected Menu Option: [${choice}]`);

    switch (choice) {
      case 1: {
        const nextId = `S10${students.length + 1}`;
        const newStu: StudentData = {
          id: nextId,
          name: 'Ananya Deshmukh',
          age: 20,
          course: 'BCA',
          semester: 4,
          marks: 88.50,
          grade: 'A'
        };
        setStudents([...students, newStu]);
        output.push(
          "---------------------------------",
          "       ADD NEW STUDENT           ",
          "---------------------------------",
          `[SUCCESS] Student ${newStu.name} (${newStu.id}) registered successfully!`,
          `+----------------------------------------+`,
          `| Student ID : ${newStu.id.padEnd(25)} |`,
          `| Name       : ${newStu.name.padEnd(25)} |`,
          `| Age        : ${String(newStu.age).padEnd(25)} |`,
          `| Course     : ${newStu.course.padEnd(25)} |`,
          `| Semester   : ${String(newStu.semester).padEnd(25)} |`,
          `| Marks      : ${newStu.marks.toFixed(2).padEnd(25)} |`,
          `| Grade      : ${(newStu.grade + ' (Excellent)').padEnd(25)} |`,
          `+----------------------------------------+`,
          `[INFO] Data synchronized with data/students.txt`
        );
        break;
      }
      case 2: {
        const avg = students.reduce((acc, s) => acc + s.marks, 0) / (students.length || 1);
        output.push(
          "-----------------------------------------------------------------------------------------",
          "                                   ALL REGISTERED STUDENTS                               ",
          "-----------------------------------------------------------------------------------------",
          "| ID       | Name                 | Age  | Course     | Sem  | Marks   | Grade  |",
          "|----------|----------------------|------|------------|------|---------|--------|"
        );
        students.forEach(s => {
          output.push(`| ${s.id.padEnd(8)} | ${s.name.padEnd(20)} | ${String(s.age).padEnd(4)} | ${s.course.padEnd(10)} | ${String(s.semester).padEnd(4)} | ${s.marks.toFixed(2).padEnd(7)} | ${s.grade.padEnd(6)} |`);
        });
        output.push(
          "-----------------------------------------------------------------------------------------",
          ` Total Students: ${students.length}   |   Class Average Marks: ${avg.toFixed(2)}%`
        );
        break;
      }
      case 3: {
        const sample = students[0];
        output.push(
          "---------------------------------",
          "         SEARCH STUDENT          ",
          "---------------------------------",
          `Query: Searching ID '${sample.id}'`,
          "[MATCH FOUND]",
          `+----------------------------------------+`,
          `| Student ID : ${sample.id.padEnd(25)} |`,
          `| Name       : ${sample.name.padEnd(25)} |`,
          `| Age        : ${String(sample.age).padEnd(25)} |`,
          `| Course     : ${sample.course.padEnd(25)} |`,
          `| Semester   : ${String(sample.semester).padEnd(25)} |`,
          `| Marks      : ${sample.marks.toFixed(2).padEnd(25)} |`,
          `| Grade      : ${sample.grade.padEnd(25)} |`,
          `+----------------------------------------+`
        );
        break;
      }
      case 4: {
        if (students.length > 0) {
          const updated = [...students];
          updated[0] = { ...updated[0], marks: 95.0, grade: 'A+' };
          setStudents(updated);
          output.push(
            "---------------------------------",
            "         UPDATE STUDENT          ",
            "---------------------------------",
            `[SUCCESS] Updated ${updated[0].id} (${updated[0].name}) marks to 95.00 -> Recalculated Grade: A+`,
            `[INFO] Changes persisted to data/students.txt`
          );
        }
        break;
      }
      case 5: {
        if (students.length > 1) {
          const removed = students[students.length - 1];
          setStudents(students.slice(0, -1));
          output.push(
            "---------------------------------",
            "         DELETE STUDENT          ",
            "---------------------------------",
            `[SUCCESS] Student record '${removed.id}' (${removed.name}) deleted successfully.`,
            `[INFO] Updated student list written to storage.`
          );
        } else {
          output.push("[!] Cannot delete last remaining student in demo mode.");
        }
        break;
      }
      case 6: {
        const res = calculateGrade(testMarks);
        output.push(
          "-------------------------------------------------",
          "             GRADE EVALUATION CENTER             ",
          "-------------------------------------------------",
          ` Scored Marks : ${testMarks.toFixed(2)} / 100.00`,
          ` Grade Awarded: ${res.grade}`,
          ` Performance  : ${res.remark}`,
          "================================="
        );
        break;
      }
      case 7: {
        output.push(
          "Saving all data to data/students.txt...",
          "=================================================",
          " Thank you for using Java First - SMS!",
          " All student data is safely saved.",
          " Have a great day!",
          "================================================="
        );
        break;
      }
      default:
        output.push("[!] Invalid choice. Select 1 to 7.");
    }

    setTerminalLogs(prev => [...prev, ...output]);
  };

  const handleConsoleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const num = parseInt(inputVal.trim());
    if (!isNaN(num) && num >= 1 && num <= 7) {
      handleRunCommand(num);
    } else if (inputVal.trim().toLowerCase() === 'clear') {
      setTerminalLogs([]);
    } else if (inputVal.trim().toLowerCase() === 'help') {
      setTerminalLogs(prev => [
        ...prev,
        "> Enter numbers 1 to 7 to trigger Java menu options, or 'clear' to reset terminal."
      ]);
    } else {
      setTerminalLogs(prev => [
        ...prev,
        `> ${inputVal}`,
        "[!] Please enter a valid menu number (1-7), or type 'help'."
      ]);
    }
    setInputVal('');
  };

  const copyToClipboard = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    setCopiedCmd(label);
    setTimeout(() => setCopiedCmd(null), 2000);
  };

  const filteredStudents = students.filter(s => 
    s.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    s.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
    s.course.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-neutral-950 text-neutral-100 flex flex-col selection:bg-amber-500/30 selection:text-amber-200">
      {/* Top Navigation Header */}
      <header className="border-b border-neutral-800 bg-neutral-900/70 backdrop-blur-md sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-amber-600 to-amber-400 flex items-center justify-center text-neutral-950 font-bold shadow-lg shadow-amber-500/10">
              <GraduationCap className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-bold text-base tracking-tight text-white">Java First</span>
                <span className="text-xs px-2 py-0.5 rounded-full bg-amber-500/10 text-amber-400 border border-amber-500/20 font-medium">Core Java</span>
              </div>
              <p className="text-xs text-neutral-400">Student Management System • BCA Project</p>
            </div>
          </div>

          {/* Navigation Tabs */}
          <nav className="flex items-center bg-neutral-950/80 p-1 rounded-xl border border-neutral-800 text-sm">
            <button
              id="tab-console"
              onClick={() => setActiveTab('console')}
              className={`flex items-center gap-2 px-3 py-1.5 rounded-lg font-medium transition-all ${
                activeTab === 'console'
                  ? 'bg-amber-500 text-neutral-950 shadow-sm'
                  : 'text-neutral-400 hover:text-neutral-200'
              }`}
            >
              <Terminal className="w-4 h-4" />
              <span>Live Console</span>
            </button>

            <button
              id="tab-code"
              onClick={() => setActiveTab('code')}
              className={`flex items-center gap-2 px-3 py-1.5 rounded-lg font-medium transition-all ${
                activeTab === 'code'
                  ? 'bg-amber-500 text-neutral-950 shadow-sm'
                  : 'text-neutral-400 hover:text-neutral-200'
              }`}
            >
              <Code2 className="w-4 h-4" />
              <span>Source Explorer</span>
            </button>

            <button
              id="tab-students"
              onClick={() => setActiveTab('students')}
              className={`flex items-center gap-2 px-3 py-1.5 rounded-lg font-medium transition-all ${
                activeTab === 'students'
                  ? 'bg-amber-500 text-neutral-950 shadow-sm'
                  : 'text-neutral-400 hover:text-neutral-200'
              }`}
            >
              <Database className="w-4 h-4" />
              <span>Data Records ({students.length})</span>
            </button>

            <button
              id="tab-guide"
              onClick={() => setActiveTab('guide')}
              className={`flex items-center gap-2 px-3 py-1.5 rounded-lg font-medium transition-all ${
                activeTab === 'guide'
                  ? 'bg-amber-500 text-neutral-950 shadow-sm'
                  : 'text-neutral-400 hover:text-neutral-200'
              }`}
            >
              <BookOpen className="w-4 h-4" />
              <span>Run Guide</span>
            </button>
          </nav>
        </div>
      </header>

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6 space-y-6">
        {/* TAB 1: Live Interactive Console */}
        {activeTab === 'console' && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Left 2 Cols: Terminal Simulator */}
            <div className="lg:col-span-2 flex flex-col h-[640px] bg-neutral-900/90 border border-neutral-800 rounded-2xl overflow-hidden shadow-2xl">
              {/* Terminal Window Header */}
              <div className="bg-neutral-950 px-4 py-3 border-b border-neutral-800 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full bg-red-500/80"></div>
                  <div className="w-3 h-3 rounded-full bg-yellow-500/80"></div>
                  <div className="w-3 h-3 rounded-full bg-green-500/80"></div>
                  <span className="text-xs text-neutral-400 font-mono ml-2">bash - java -cp bin Main</span>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => setTerminalLogs([
                      "=================================================",
                      "            JAVA FIRST: STUDENT MANAGEMENT       ",
                      "=================================================",
                      " Welcome to the BCA Core Java Management System! ",
                      " Persistent Data File: data/students.txt         ",
                      " Total Records Loaded: " + students.length,
                      "================================================="
                    ])}
                    className="text-xs text-neutral-400 hover:text-neutral-200 flex items-center gap-1 bg-neutral-800/60 px-2 py-1 rounded"
                  >
                    <RotateCcw className="w-3 h-3" />
                    Reset
                  </button>
                </div>
              </div>

              {/* Terminal Output Body */}
              <div className="flex-1 p-4 font-mono text-xs sm:text-sm text-neutral-300 overflow-y-auto space-y-1 bg-black/40">
                {terminalLogs.map((log, idx) => (
                  <div 
                    key={idx} 
                    className={
                      log.includes('[SUCCESS]') 
                        ? 'text-emerald-400' 
                        : log.includes('[ERROR]') || log.includes('[!]') 
                        ? 'text-rose-400' 
                        : log.includes('JAVA FIRST') 
                        ? 'text-amber-400 font-bold' 
                        : log.startsWith('>') 
                        ? 'text-cyan-300' 
                        : 'text-neutral-300'
                    }
                  >
                    {log}
                  </div>
                ))}
                <div ref={terminalEndRef} />
              </div>

              {/* Terminal Input Form */}
              <form onSubmit={handleConsoleSubmit} className="border-t border-neutral-800 bg-neutral-950 p-3 flex items-center gap-3">
                <span className="text-amber-400 font-mono text-sm font-bold">&gt;</span>
                <input
                  type="text"
                  value={inputVal}
                  onChange={(e) => setInputVal(e.target.value)}
                  placeholder="Enter choice (1-7) or type 'help' / 'clear'..."
                  className="flex-1 bg-transparent border-none text-white text-sm font-mono focus:outline-none placeholder:text-neutral-600"
                />
                <button
                  type="submit"
                  className="px-3 py-1.5 bg-amber-500 hover:bg-amber-400 text-neutral-950 font-semibold text-xs rounded-lg transition-colors flex items-center gap-1"
                >
                  <Play className="w-3.5 h-3.5 fill-current" />
                  Execute
                </button>
              </form>
            </div>

            {/* Right 1 Col: Quick Action Pad & Metrics */}
            <div className="space-y-6">
              {/* Quick Actions Panel */}
              <div className="bg-neutral-900/60 border border-neutral-800 rounded-2xl p-5 space-y-4">
                <h3 className="font-semibold text-sm text-neutral-200 flex items-center gap-2">
                  <Play className="w-4 h-4 text-amber-400" />
                  Interactive Menu Launcher
                </h3>
                <p className="text-xs text-neutral-400">
                  Click any option below to test Java logic immediately in the simulator:
                </p>

                <div className="grid grid-cols-1 gap-2">
                  <button
                    onClick={() => handleRunCommand(1)}
                    className="w-full text-left px-3 py-2.5 rounded-xl bg-neutral-800/70 hover:bg-neutral-800 border border-neutral-700/60 text-xs text-neutral-200 flex items-center justify-between group transition-all"
                  >
                    <span className="flex items-center gap-2">
                      <span className="w-5 h-5 rounded bg-amber-500/20 text-amber-400 flex items-center justify-center font-bold text-[10px]">1</span>
                      Add Sample Student
                    </span>
                    <Plus className="w-3.5 h-3.5 text-neutral-400 group-hover:text-amber-400" />
                  </button>

                  <button
                    onClick={() => handleRunCommand(2)}
                    className="w-full text-left px-3 py-2.5 rounded-xl bg-neutral-800/70 hover:bg-neutral-800 border border-neutral-700/60 text-xs text-neutral-200 flex items-center justify-between group transition-all"
                  >
                    <span className="flex items-center gap-2">
                      <span className="w-5 h-5 rounded bg-amber-500/20 text-amber-400 flex items-center justify-center font-bold text-[10px]">2</span>
                      View All Students (Table)
                    </span>
                    <Users className="w-3.5 h-3.5 text-neutral-400 group-hover:text-amber-400" />
                  </button>

                  <button
                    onClick={() => handleRunCommand(3)}
                    className="w-full text-left px-3 py-2.5 rounded-xl bg-neutral-800/70 hover:bg-neutral-800 border border-neutral-700/60 text-xs text-neutral-200 flex items-center justify-between group transition-all"
                  >
                    <span className="flex items-center gap-2">
                      <span className="w-5 h-5 rounded bg-amber-500/20 text-amber-400 flex items-center justify-center font-bold text-[10px]">3</span>
                      Search Student (S101)
                    </span>
                    <Search className="w-3.5 h-3.5 text-neutral-400 group-hover:text-amber-400" />
                  </button>

                  <button
                    onClick={() => handleRunCommand(4)}
                    className="w-full text-left px-3 py-2.5 rounded-xl bg-neutral-800/70 hover:bg-neutral-800 border border-neutral-700/60 text-xs text-neutral-200 flex items-center justify-between group transition-all"
                  >
                    <span className="flex items-center gap-2">
                      <span className="w-5 h-5 rounded bg-amber-500/20 text-amber-400 flex items-center justify-center font-bold text-[10px]">4</span>
                      Update Student Record
                    </span>
                    <Edit3 className="w-3.5 h-3.5 text-neutral-400 group-hover:text-amber-400" />
                  </button>

                  <button
                    onClick={() => handleRunCommand(5)}
                    className="w-full text-left px-3 py-2.5 rounded-xl bg-neutral-800/70 hover:bg-neutral-800 border border-neutral-700/60 text-xs text-neutral-200 flex items-center justify-between group transition-all"
                  >
                    <span className="flex items-center gap-2">
                      <span className="w-5 h-5 rounded bg-amber-500/20 text-amber-400 flex items-center justify-center font-bold text-[10px]">5</span>
                      Delete Last Student
                    </span>
                    <Trash2 className="w-3.5 h-3.5 text-neutral-400 group-hover:text-rose-400" />
                  </button>

                  <button
                    onClick={() => handleRunCommand(6)}
                    className="w-full text-left px-3 py-2.5 rounded-xl bg-neutral-800/70 hover:bg-neutral-800 border border-neutral-700/60 text-xs text-neutral-200 flex items-center justify-between group transition-all"
                  >
                    <span className="flex items-center gap-2">
                      <span className="w-5 h-5 rounded bg-amber-500/20 text-amber-400 flex items-center justify-center font-bold text-[10px]">6</span>
                      Grade Evaluation
                    </span>
                    <Award className="w-3.5 h-3.5 text-neutral-400 group-hover:text-amber-400" />
                  </button>

                  <button
                    onClick={() => handleRunCommand(7)}
                    className="w-full text-left px-3 py-2.5 rounded-xl bg-neutral-800/70 hover:bg-neutral-800 border border-neutral-700/60 text-xs text-neutral-200 flex items-center justify-between group transition-all"
                  >
                    <span className="flex items-center gap-2">
                      <span className="w-5 h-5 rounded bg-amber-500/20 text-amber-400 flex items-center justify-center font-bold text-[10px]">7</span>
                      Sync & Exit
                    </span>
                    <HardDrive className="w-3.5 h-3.5 text-neutral-400 group-hover:text-emerald-400" />
                  </button>
                </div>
              </div>

              {/* Interactive Grade Calculator Mini-Tool */}
              <div className="bg-neutral-900/60 border border-neutral-800 rounded-2xl p-5 space-y-4">
                <h3 className="font-semibold text-sm text-neutral-200 flex items-center gap-2">
                  <Award className="w-4 h-4 text-amber-400" />
                  Live Grade Tester
                </h3>
                <div className="space-y-3">
                  <div>
                    <label className="text-xs text-neutral-400 block mb-1">Enter Marks Percentage (0 - 100):</label>
                    <input
                      type="number"
                      min="0"
                      max="100"
                      step="0.5"
                      value={testMarks}
                      onChange={(e) => {
                        const val = parseFloat(e.target.value) || 0;
                        setTestMarks(val);
                        setGradeResult(calculateGrade(val));
                      }}
                      className="w-full bg-neutral-950 border border-neutral-800 rounded-xl px-3 py-2 text-sm text-white font-mono focus:border-amber-500 focus:outline-none"
                    />
                  </div>
                  <div className="p-3 bg-neutral-950/80 rounded-xl border border-neutral-800/80 flex items-center justify-between">
                    <div>
                      <span className="text-xs text-neutral-400 block">Computed Grade:</span>
                      <span className="text-lg font-bold text-amber-400">{gradeResult.grade}</span>
                    </div>
                    <span className="text-xs text-neutral-300 bg-neutral-800 px-2.5 py-1 rounded-md">
                      {gradeResult.remark}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* TAB 2: Java Source Code Explorer */}
        {activeTab === 'code' && (
          <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
            {/* File List Tree */}
            <div className="lg:col-span-1 bg-neutral-900/60 border border-neutral-800 rounded-2xl p-4 space-y-3">
              <h3 className="font-semibold text-sm text-neutral-200 flex items-center gap-2">
                <FolderTree className="w-4 h-4 text-amber-400" />
                Java Architecture
              </h3>
              <p className="text-xs text-neutral-400">
                Single-responsibility Core Java structure:
              </p>

              <div className="space-y-1">
                {Object.entries(JAVA_CODE_FILES).map(([key, item]) => (
                  <button
                    key={key}
                    onClick={() => setSelectedFile(key)}
                    className={`w-full text-left px-3 py-2.5 rounded-xl text-xs font-mono flex items-center justify-between transition-all ${
                      selectedFile === key
                        ? 'bg-amber-500/10 text-amber-400 border border-amber-500/30'
                        : 'text-neutral-400 hover:text-neutral-200 hover:bg-neutral-800/50'
                    }`}
                  >
                    <span className="flex items-center gap-2">
                      <FileText className="w-3.5 h-3.5" />
                      {item.filename}
                    </span>
                    <ChevronRight className="w-3 h-3 opacity-60" />
                  </button>
                ))}
              </div>

              {/* Concept tags */}
              <div className="pt-4 border-t border-neutral-800 space-y-2">
                <span className="text-xs font-medium text-neutral-400 block">Demonstrated Concepts:</span>
                <div className="flex flex-wrap gap-1.5">
                  {['Encapsulation', 'ArrayList', 'File I/O', 'Constructors', 'Exceptions', 'Scanner'].map(t => (
                    <span key={t} className="text-[10px] bg-neutral-800 text-neutral-300 px-2 py-0.5 rounded-md border border-neutral-700/50">
                      {t}
                    </span>
                  ))}
                </div>
              </div>
            </div>

            {/* Code Viewer Panel */}
            <div className="lg:col-span-3 bg-neutral-900/80 border border-neutral-800 rounded-2xl overflow-hidden flex flex-col">
              <div className="bg-neutral-950 px-5 py-3.5 border-b border-neutral-800 flex items-center justify-between">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-sm font-semibold text-white">{JAVA_CODE_FILES[selectedFile].path}</span>
                    <span className="text-[10px] px-2 py-0.5 bg-amber-500/10 text-amber-400 rounded-md uppercase font-bold">
                      {JAVA_CODE_FILES[selectedFile].language}
                    </span>
                  </div>
                  <p className="text-xs text-neutral-400 mt-0.5">{JAVA_CODE_FILES[selectedFile].description}</p>
                </div>
                <button
                  onClick={() => copyToClipboard(JAVA_CODE_FILES[selectedFile].code, selectedFile)}
                  className="text-xs flex items-center gap-1.5 bg-neutral-800 hover:bg-neutral-700 text-neutral-200 px-3 py-1.5 rounded-lg transition-colors"
                >
                  {copiedCmd === selectedFile ? (
                    <>
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                      Copied
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5" />
                      Copy Code
                    </>
                  )}
                </button>
              </div>
              <div className="p-5 font-mono text-xs sm:text-sm text-neutral-300 overflow-x-auto bg-black/40 leading-relaxed">
                <pre>{JAVA_CODE_FILES[selectedFile].code}</pre>
              </div>
            </div>
          </div>
        )}

        {/* TAB 3: Data Records Table */}
        {activeTab === 'students' && (
          <div className="bg-neutral-900/60 border border-neutral-800 rounded-2xl p-6 space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h3 className="font-semibold text-base text-white flex items-center gap-2">
                  <Database className="w-5 h-5 text-amber-400" />
                  Persistent Storage Inspector (`data/students.txt`)
                </h3>
                <p className="text-xs text-neutral-400 mt-1">
                  Records loaded from local disk file using CSV parsing format: <code className="text-amber-300">StudentID,Name,Age,Course,Semester,Marks,Grade</code>
                </p>
              </div>

              {/* Search filter */}
              <div className="relative">
                <Search className="w-4 h-4 text-neutral-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  placeholder="Filter by name, ID or course..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="bg-neutral-950 border border-neutral-800 rounded-xl pl-9 pr-4 py-2 text-xs text-white placeholder:text-neutral-500 focus:outline-none focus:border-amber-500 w-full sm:w-64"
                />
              </div>
            </div>

            {/* Students Table */}
            <div className="overflow-x-auto rounded-xl border border-neutral-800">
              <table className="w-full text-left text-xs sm:text-sm">
                <thead className="bg-neutral-950 text-neutral-400 uppercase text-[11px] font-semibold border-b border-neutral-800">
                  <tr>
                    <th className="px-4 py-3">Student ID</th>
                    <th className="px-4 py-3">Full Name</th>
                    <th className="px-4 py-3">Age</th>
                    <th className="px-4 py-3">Course</th>
                    <th className="px-4 py-3">Semester</th>
                    <th className="px-4 py-3">Marks</th>
                    <th className="px-4 py-3">Grade</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-neutral-800 font-mono">
                  {filteredStudents.map((s) => (
                    <tr key={s.id} className="hover:bg-neutral-800/40 transition-colors">
                      <td className="px-4 py-3 font-bold text-amber-400">{s.id}</td>
                      <td className="px-4 py-3 text-white font-sans">{s.name}</td>
                      <td className="px-4 py-3 text-neutral-300">{s.age}</td>
                      <td className="px-4 py-3 text-neutral-300">{s.course}</td>
                      <td className="px-4 py-3 text-neutral-300">Sem {s.semester}</td>
                      <td className="px-4 py-3 text-neutral-200">{s.marks.toFixed(2)}</td>
                      <td className="px-4 py-3">
                        <span className={`px-2.5 py-0.5 rounded-full text-xs font-bold ${
                          s.grade === 'A+' ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30' :
                          s.grade === 'A' ? 'bg-teal-500/20 text-teal-400 border border-teal-500/30' :
                          s.grade === 'B' ? 'bg-cyan-500/20 text-cyan-400 border border-cyan-500/30' :
                          s.grade === 'C' ? 'bg-yellow-500/20 text-yellow-400 border border-yellow-500/30' :
                          s.grade === 'D' ? 'bg-orange-500/20 text-orange-400 border border-orange-500/30' :
                          'bg-rose-500/20 text-rose-400 border border-rose-500/30'
                        }`}>
                          {s.grade}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Metrics summary banner */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-2">
              <div className="bg-neutral-950/70 p-4 rounded-xl border border-neutral-800 flex items-center gap-3">
                <Users className="w-6 h-6 text-amber-400" />
                <div>
                  <span className="text-xs text-neutral-400 block">Total Enrolled</span>
                  <span className="text-xl font-bold text-white">{students.length} Students</span>
                </div>
              </div>

              <div className="bg-neutral-950/70 p-4 rounded-xl border border-neutral-800 flex items-center gap-3">
                <Award className="w-6 h-6 text-emerald-400" />
                <div>
                  <span className="text-xs text-neutral-400 block">Class Average</span>
                  <span className="text-xl font-bold text-white">
                    {(students.reduce((acc, s) => acc + s.marks, 0) / (students.length || 1)).toFixed(2)}%
                  </span>
                </div>
              </div>

              <div className="bg-neutral-950/70 p-4 rounded-xl border border-neutral-800 flex items-center gap-3">
                <HardDrive className="w-6 h-6 text-cyan-400" />
                <div>
                  <span className="text-xs text-neutral-400 block">Persistence Strategy</span>
                  <span className="text-sm font-semibold text-neutral-200">Local Flat-File I/O</span>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* TAB 4: Run & Setup Guide */}
        {activeTab === 'guide' && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Command Line Run Guide */}
            <div className="bg-neutral-900/60 border border-neutral-800 rounded-2xl p-6 space-y-4">
              <h3 className="font-semibold text-base text-white flex items-center gap-2">
                <Terminal className="w-5 h-5 text-amber-400" />
                Command Line Execution
              </h3>
              <p className="text-xs text-neutral-400">
                Run these standard commands in your terminal to compile and launch:
              </p>

              <div className="space-y-3">
                <div>
                  <div className="flex items-center justify-between text-xs text-neutral-300 mb-1">
                    <span>1. Linux / macOS:</span>
                    <button
                      onClick={() => copyToClipboard('javac -d bin src/*.java && java -cp bin Main', 'cmd1')}
                      className="text-amber-400 hover:text-amber-300 text-[11px] flex items-center gap-1"
                    >
                      {copiedCmd === 'cmd1' ? 'Copied!' : 'Copy'}
                    </button>
                  </div>
                  <pre className="bg-neutral-950 p-3 rounded-xl border border-neutral-800 text-xs font-mono text-amber-200">
                    javac -d bin src/*.java&#10;java -cp bin Main
                  </pre>
                </div>

                <div>
                  <div className="flex items-center justify-between text-xs text-neutral-300 mb-1">
                    <span>2. Windows (CMD / PowerShell):</span>
                    <button
                      onClick={() => copyToClipboard('javac -d bin src\\*.java\njava -cp bin Main', 'cmd2')}
                      className="text-amber-400 hover:text-amber-300 text-[11px] flex items-center gap-1"
                    >
                      {copiedCmd === 'cmd2' ? 'Copied!' : 'Copy'}
                    </button>
                  </div>
                  <pre className="bg-neutral-950 p-3 rounded-xl border border-neutral-800 text-xs font-mono text-amber-200">
                    javac -d bin src\*.java&#10;java -cp bin Main
                  </pre>
                </div>

                <div>
                  <div className="flex items-center justify-between text-xs text-neutral-300 mb-1">
                    <span>3. Single-Click Script:</span>
                    <button
                      onClick={() => copyToClipboard('./run.sh', 'cmd3')}
                      className="text-amber-400 hover:text-amber-300 text-[11px] flex items-center gap-1"
                    >
                      {copiedCmd === 'cmd3' ? 'Copied!' : 'Copy'}
                    </button>
                  </div>
                  <pre className="bg-neutral-950 p-3 rounded-xl border border-neutral-800 text-xs font-mono text-neutral-300">
                    ./run.sh  # or run.bat on Windows
                  </pre>
                </div>
              </div>
            </div>

            {/* Academic Evaluation & Concept Reference */}
            <div className="bg-neutral-900/60 border border-neutral-800 rounded-2xl p-6 space-y-4">
              <h3 className="font-semibold text-base text-white flex items-center gap-2">
                <BookOpen className="w-5 h-5 text-amber-400" />
                BCA Java Syllabus Mapping
              </h3>
              <div className="space-y-2.5 text-xs text-neutral-300">
                <div className="p-3 bg-neutral-950 rounded-xl border border-neutral-800">
                  <span className="font-semibold text-amber-400 block mb-0.5">Classes & Encapsulation</span>
                  <code className="text-amber-300">Student.java</code> protects entity state using private fields and validated getters/setters.
                </div>
                <div className="p-3 bg-neutral-950 rounded-xl border border-neutral-800">
                  <span className="font-semibold text-amber-400 block mb-0.5">Collections Framework</span>
                  <code className="text-amber-300">StudentManager.java</code> manages dynamic records using <code className="text-amber-300">ArrayList&lt;Student&gt;</code>.
                </div>
                <div className="p-3 bg-neutral-950 rounded-xl border border-neutral-800">
                  <span className="font-semibold text-amber-400 block mb-0.5">File Streams & Try-with-Resources</span>
                  <code className="text-amber-300">FileHandler.java</code> uses <code className="text-amber-300">BufferedReader</code> / <code className="text-amber-300">BufferedWriter</code> for safe flat-file persistence.
                </div>
                <div className="p-3 bg-neutral-950 rounded-xl border border-neutral-800">
                  <span className="font-semibold text-amber-400 block mb-0.5">Defensive Input Validation</span>
                  <code className="text-amber-300">Main.java</code> handles <code className="text-amber-300">NumberFormatException</code> and out-of-range choices to prevent runtime crashes.
                </div>
              </div>
            </div>
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="border-t border-neutral-800 py-4 bg-neutral-950 text-neutral-500 text-xs text-center">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-2">
          <span>Java First – Student Management System (BCA Core Java Project)</span>
          <span>Pure Core Java • Zero External Frameworks</span>
        </div>
      </footer>
    </div>
  );
}
